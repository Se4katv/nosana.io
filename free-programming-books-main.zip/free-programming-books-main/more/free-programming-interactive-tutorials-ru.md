### Index

* [Веб-разработка](#Веб-разработка)
* [Git](#git)
* [Python](#Python)
* [SQL](#SQL)


### Веб-разработка

* [Учитесь веб-разработке бесплатно!](http://codenamecrud.ru)
* [Open source воркшопы](https://nodeschool.io/ru)


### Git

* [Интерактивное обучение работе с git](https://githowto.com/ru)
* [Обучение git при помощи визуализации](https://learngitbranching.js.org/?locale=ru_RU)


### Python

* [Pythontutor](https://pythontutor.ru)


### SQL

* [SQL упражнения](https://www.sql-ex.ru/?Lang=0)


