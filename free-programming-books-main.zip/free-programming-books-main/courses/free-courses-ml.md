### Index

* [Android](#android)
* [Javascript](#javascript)
* [PHP](#php)
* [Python](#python)
  * [Django](#django)


### Android

* [Android App Development Tutorial Malayalam](https://youtube.com/playlist?list=PLZ78Q1BKkdA1-eMVQOiBiMtQQb_vYWnvV) - Sabith Pkc Mnr


### Javascript

* [JavaScript Malayalam Tutorial](https://www.youtube.com/watch?v=3mjwtu4_0uk) - Yes Tech Media


### PHP

* [PHP Programming Malayalam Tutorial for Beginners](https://www.youtube.com/watch?v=nFYWCouZ1UA) - Yes Tech Media


### Python

* [Python Programming Malayalam Tutorial](https://www.youtube.com/watch?v=ihnWXGPxNEk) - Yes Tech Media


#### Django

* [Python Django malayalam tutorial](https://www.youtube.com/watch?v=Obu5qj9sdaE) - Tintu Vlogger
* [Python Django Tutorial for Beginners in malayalam](https://www.youtube.com/playlist?list=PLbasZIkCgHJGXEjcatJ3aO1NpS2PsOtoQ) - Code Band 
