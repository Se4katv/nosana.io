### Index

* [C++](#cpp)
* [Java](#java)
* [Python](#python)


### <a id="cpp"></a>C++

* [Мова програмування C++](https://stepik.org/course/67114) - Stepik


### Java

* [Основи програмування на Java](https://courses.prometheus.org.ua/courses/EPAM/JAVA101/2016_T2/about)


### Python

* [Python 2: Курс Молодого Бійця](http://www.vitaliypodoba.com/tutorials/python2-beginners-course/) - Віталій Подоба
* [Основи програмування на Python](https://courses.prometheus.org.ua/courses/KPI/Programming101/2015_T1/about) - Нікіта Павлюченко (email address *required*, phone number *required*)
* [Програмування на мові Python (3.x). Початковий курс](https://sites.google.com/site/pythonukr/vstup)
