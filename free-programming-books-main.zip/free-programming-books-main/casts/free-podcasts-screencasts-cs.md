### Podcasty

* [Brus kódu](http://bruskodu.cz) - pro frontend vývojáře
* [CZpodcast](https://soundcloud.com/czpodcast-1)
* [DevMinutes](http://devminutes.cz)
* [Kafemlejnek.TV](https://kafemlejnek.tv)
