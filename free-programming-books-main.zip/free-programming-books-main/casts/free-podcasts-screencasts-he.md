### כללי

* [מפתחים חסרי תרבות](http://notarbut.co) (פודקאסט)
* [עושים תוכנה](https://www.osimhistoria.com/software) (פודקאסט)
* [פרונטאנד לנד](https://podcastim.org.il/פרונטאנד-לנד) (פודקאסט)
* [צרות בהייטק](https://hitechproblems.podbean.com) (פודקאסט)
* [רברס עם פלטפורמה](https://www.reversim.com) (פודקאסט)
