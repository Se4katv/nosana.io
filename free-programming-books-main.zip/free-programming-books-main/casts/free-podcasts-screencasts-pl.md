### Index

* [Niezależne od języka programowania](#niezale%C5%BCne-od-j%C4%99zyka-programowania)


### Niezależne od języka programowania

* [DevTalk](https://devstyle.pl/category/podcast)
* [Rozmowa Kontrolowana](https://www.youtube.com/playlist?list=PLTKLAGr6FHxOcW4NRX3BCkU7Zml92WU1u) - Zaufana Trzecia Strona (screencast)
