### Podcast

* [Ceritanya Developer Podcast](https://anchor.fm/ceritanya-developer) (podcast)
* [Developer Muslim](https://anchor.fm/devmuslimid) - Adinda Praditya (podcast)
