### Index

* [Ajax](#ajax)
* [HTML](#html)
* [MySQL](#mysql)
* [PHP](#php)
  * [Symfony](#symfony)
* [Scratch](#scratch)


### Ajax

* [Ajax](http://etutoriale.ro/articles/1483/1/Tutorial-Ajax/)


### HTML

* [HTML](http://tutorialehtml.com/ro/introducere-in-html/)


### MySQL

* [MySQL](http://profs.info.uaic.ro/~busaco/teach/courses/net/docs/mysql-ro.pdf) (PDF)


### PHP

* [PHP](http://php.punctsivirgula.ro)


#### Symfony

* [Symfony 5: Curs rapid](https://symfony.com/doc/current/the-fast-track/ro/index.html)


### Scratch

* [Informatica Creativa](http://scratched.gse.harvard.edu/resources/informatica-creativa-0)
