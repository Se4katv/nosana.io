### Index

* [C](#c)
* [C#](#csharp)
* [C++](#cpp)
* [Java](#java)
* [Pascal](#pascal)


### C

* [Programmering i C](http://people.cs.aau.dk/~normark/c-prog-06/pdf/all.pdf) - Kurt Nørmark (PDF)


### <a id="csharp"></a>C\#

* [Object-oriented Programming in C#](http://people.cs.aau.dk/~normark/oop-csharp/pdf/all.pdf) - Kurt Nørmark (PDF)


### <a id="cpp"></a>C++

* [Notes about C++](http://people.cs.aau.dk/~normark/ap/index.html) - Kurt Nørmark (HTML)


### Java

* [Objektorienteret programmering i Java](http://javabog.dk) - Jacob Nordfalk


### Pascal

* [Programmering i Pascal](http://people.cs.aau.dk/~normark/all-basis-97.pdf) - Kurt Nørmark (PDF)
